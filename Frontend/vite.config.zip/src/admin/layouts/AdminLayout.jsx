import { useState } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import Sidebar from '../components/Sidebar'
import Header from '../components/Header'

export default function AdminLayout() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false)
  const location = useLocation()
  const isMobile = window.innerWidth < 1024

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-[#082B3B] flex relative overflow-hidden">
      {isMobile ? (
        <>
          <button
            onClick={() => setMobileDrawerOpen((p) => !p)}
            className="fixed top-4 left-4 z-[1150] p-2 bg-white dark:bg-[#0F2B30] text-gray-600 dark:text-white rounded-lg shadow-lg border border-gray-200 dark:border-[#1E3A3D]"
            aria-label="Open navigation"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>
          </button>
          <Sidebar isMobile isOpen={mobileDrawerOpen} onToggle={setMobileDrawerOpen} />
        </>
      ) : (
        <Sidebar collapsed={sidebarCollapsed} onToggle={setSidebarCollapsed} />
      )}
      <div className={`flex-1 flex flex-col min-h-[100svh] transition-margin duration-300 ${isMobile || sidebarCollapsed ? 'ml-0' : 'ml-64 lg:ml-[calc(256px_-_1rem)]'}`}>
        <Header />
        <main className="flex-1 p-4 md:p-6 overflow-y-auto bg-[#F8FAFC] dark:bg-[#082B3B]">
          <Outlet context={{ location }} />
        </main>
      </div>
    </div>
  )
}
