import { useState } from 'react'

export function useTheme() {
  const saved = localStorage.getItem('avenor-admin-theme')
  const [theme, setTheme] = useState(() => (saved ? saved : 'light'))

  if (typeof document !== 'undefined') {
    document.documentElement.setAttribute('data-theme', theme)
  }

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light'
    setTheme(newTheme)
    document.documentElement.setAttribute('data-theme', newTheme)
    localStorage.setItem('avenor-admin-theme', newTheme)
  }

  return { theme, toggleTheme, setTheme }
}

export default useTheme
