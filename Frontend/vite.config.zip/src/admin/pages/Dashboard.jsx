import { Link } from 'react-router-dom'
import { Calendar, Users, User, Building2, CreditCard, Activity, ChevronRight } from 'lucide-react'
import { StatCard } from '../components/StatCard'
import { DataTable } from '../components/DataTable'
import { PatientTrendChart, RevenueChart, StatusChart } from '../components/charts'
import {
  demoStats, patientTrendData, appointmentStatusData, revenueData,
  recentAppointments, patients, departments, activityLog,
} from '../data/demoData'

const statusColor = {
  Scheduled: 'bg-[#003B3D]/10 text-[#003B3D]',
  Completed: 'bg-[#10B981]/10 text-[#10B981]',
  Pending: 'bg-[#F59E0B]/10 text-[#F59E0B]',
  Cancelled: 'bg-[#EF4444]/10 text-[#EF4444]',
}

export default function Dashboard() {

  const statCards = [
    { title: 'Total Patients', value: demoStats.totalPatients, trend: +5.6, icon: Users, subtitle: demoStats.previousPeriod.totalPatients.toLocaleString() + ' last period' },
    { title: "Today's Appointments", value: demoStats.todayAppointments, trend: +16.7, icon: Calendar, subtitle: demoStats.previousPeriod.todayAppointments.toLocaleString() + ' last period' },
    { title: 'Available Doctors', value: demoStats.availableDoctors, trend: +7.7, icon: User, subtitle: demoStats.previousPeriod.availableDoctors.toLocaleString() + ' last period' },
    { title: 'Total Revenue', value: `₦${demoStats.totalRevenue.toLocaleString()}`, trend: +9.8, icon: CreditCard, subtitle: '₦' + demoStats.previousPeriod.totalRevenue.toLocaleString() + ' last period' },
  ]

  const statusBadge = (status) => (
    <span className={`px-2 py-0.5 rounded text-xs font-medium ${statusColor[status] || 'bg-gray-100 text-gray-600'}`}>
      {status}
    </span>
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="font-serif text-2xl font-bold text-[#0F172A] dark:text-white">Dashboard</h1>
          <p className="text-[#64748B] dark:text-[#94A3B8] text-sm">Welcome back, Administrator. Here's what's happening at Avenor today.</p>
        </div>
        <div className="flex gap-2">
          <button className="px-4 py-2 rounded-xl border border-gray-200 dark:border-[#1E3A3D] text-gray-700 dark:text-gray-300 bg-white dark:bg-[#0F2B30] hover:bg-gray-50 dark:hover:bg-[#163A3F] text-sm font-medium transition">
            Export Report
          </button>
          <button className="px-4 py-2 rounded-xl bg-[#003B3D] text-white text-sm font-medium hover:bg-[#082B3B] transition">
            Quick Actions
          </button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {statCards.map((card, i) => (
          <StatCard key={i} title={card.title} value={card.value} trend={card.trend} Icon={card.icon} subtitle={card.subtitle} />
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <div className="lg:col-span-2 bg-white dark:bg-[#0F2B30] rounded-2xl border border-[#E2E8F0] dark:border-[#1E3A3D] p-6 shadow-sm">
          <h2 className="font-serif text-lg font-bold text-[#0F172A] dark:text-white mb-4 flex items-center gap-2">
            <Activity size={18} className="text-[#003B3D]" /> Patient &amp; Appointment Trends
          </h2>
          <PatientTrendChart data={patientTrendData} />
        </div>
        <div className="bg-white dark:bg-[#0F2B30] rounded-2xl border border-[#E2E8F0] dark:border-[#1E3A3D] p-6 shadow-sm">
          <h2 className="font-serif text-lg font-bold text-[#0F172A] dark:text-white mb-4 flex items-center gap-2">
            <Calendar size={18} className="text-[#003B3D]" /> Appointment Status
          </h2>
          <StatusChart data={appointmentStatusData} />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <div className="bg-white dark:bg-[#0F2B30] rounded-2xl border border-[#E2E8F0] dark:border-[#1E3A3D] p-6 shadow-sm">
          <h2 className="font-serif text-lg font-bold text-[#0F172A] dark:text-white mb-4 flex items-center gap-2">
            <CreditCard size={18} className="text-[#003B3D]" /> Revenue Overview
          </h2>
          <RevenueChart data={revenueData} />
        </div>
        <div className="lg:col-span-2 bg-white dark:bg-[#0F2B30] rounded-2xl border border-[#E2E8F0] dark:border-[#1E3A3D] p-6 shadow-sm">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
            <div>
              <h2 className="font-serif text-lg font-bold text-[#0F172A] dark:text-white">Recent Appointments</h2>
              <p className="text-[#64748B] dark:text-[#94A3B8] text-sm">Latest scheduled and completed patient visits.</p>
            </div>
            <Link to="/admin/appointments" className="text-sm font-medium text-[#003B3D] hover:text-[#082B3B] flex items-center gap-1 transition">
              View all <ChevronRight size={14} />
            </Link>
          </div>
          <DataTable
            columns={[
              { key: 'id', label: 'ID' },
              { key: 'patient', label: 'Patient' },
              { key: 'doctor', label: 'Doctor' },
              { key: 'specialty', label: 'Specialty' },
              { key: 'date', label: 'Date' },
              { key: 'time', label: 'Time' },
              { key: 'status', label: 'Status', render: (val) => statusBadge(val) },
            ]}
            data={recentAppointments}
            pageSize={5}
            searchable={false}
            emptyMessage="No recent appointments"
          />
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <div className="bg-white dark:bg-[#0F2B30] rounded-2xl border border-[#E2E8F0] dark:border-[#1E3A3D] p-6 shadow-sm">
          <h2 className="font-serif text-lg font-bold text-[#0F172A] dark:text-white mb-4 flex items-center gap-2">
            <Users size={18} className="text-[#003B3D]" /> Recent Patient Registrations
          </h2>
          <div className="space-y-3">
            {patients.slice(0, 4).map((p) => (
              <div key={p.id} className="flex items-center gap-3 p-3 rounded-xl bg-gray-50 dark:bg-[#163A3F] border border-gray-100 dark:border-transparent">
                <div className="w-10 h-10 rounded-full bg-[#003B3D]/10 flex items-center justify-center text-[#003B3D] text-sm font-semibold">
                  {p.name.charAt(0)}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-[#0F172A] dark:text-white">{p.name}</p>
                  <p className="text-xs text-[#64748B] dark:text-[#94A3B8]">{p.id} • {p.gender}, {p.age}</p>
                </div>
                <span className="px-2 py-1 rounded text-[10px] font-medium bg-[#10B981]/10 text-[#10B981]">{p.status}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="lg:col-span-2 bg-white dark:bg-[#0F2B30] rounded-2xl border border-[#E2E8F0] dark:border-[#1E3A3D] p-6 shadow-sm">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
            <div>
              <h2 className="font-serif text-lg font-bold text-[#0F172A] dark:text-white flex items-center gap-2">
                <Building2 size={18} className="text-[#003B3D]" /> Department Performance
              </h2>
              <p className="text-[#64748B] dark:text-[#94A3B8] text-sm">Patient load and revenue by department.</p>
            </div>
          </div>
          <DataTable
            columns={[
              { key: 'name', label: 'Department' },
              { key: 'head', label: 'Head of Department' },
              { key: 'doctors', label: 'Doctors' },
              { key: 'patients', label: 'Patients' },
              { key: 'revenue', label: 'Revenue', render: (v) => '₦' + v.toLocaleString() },
              { key: 'status', label: 'Status', render: (val) => <span className="px-2 py-1 rounded text-[10px] font-medium bg-[#10B981]/10 text-[#10B981]">{val}</span> },
            ]}
            data={departments}
            pageSize={5}
            searchable={false}
            emptyMessage="No departments"
          />
        </div>
      </div>

      <div className="bg-white dark:bg-[#0F2B30] rounded-2xl border border-[#E2E8F0] dark:border-[#1E3A3D] p-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-4">
          <div>
            <h2 className="font-serif text-lg font-bold text-[#0F172A] dark:text-white flex items-center gap-2">
              <Activity size={18} className="text-[#003B3D]" /> Recent Administrative Activity
            </h2>
            <p className="text-[#64748B] dark:text-[#94A3B8] text-sm">Audit trail of recent actions taken in the admin dashboard.</p>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm divide-y divide-[#E2E8F0] dark:divide-[#1E3A3D]">
            <thead className="bg-gray-50 dark:bg-[#163A3F]">
              <tr>
                <th className="px-4 py-3 text-left font-medium text-gray-700 dark:text-gray-300">Action</th>
                <th className="px-4 py-3 text-left font-medium text-gray-700 dark:text-gray-300">User</th>
                <th className="px-4 py-3 text-left font-medium text-gray-700 dark:text-gray-300">Details</th>
                <th className="px-4 py-3 text-left font-medium text-gray-700 dark:text-gray-300">Time</th>
              </tr>
            </thead>
            <tbody>
              {activityLog.map((a) => (
                <tr key={a.action + a.time} className="bg-white dark:bg-[#0F2B30]">
                  <td className="px-4 py-3 text-gray-900 dark:text-white">{a.action}</td>
                  <td className="px-4 py-3 text-gray-900 dark:text-white">{a.user}</td>
                  <td className="px-4 py-3 text-[#64748B] dark:text-[#94A3B8]">{a.details}</td>
                  <td className="px-4 py-3 text-[#64748B] dark:text-[#94A3B8] text-sm">{a.time}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
