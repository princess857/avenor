import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Bar, BarChart,
  PieChart, Pie, Cell, Legend,
} from 'recharts'

const COLORS = ['#003B3D', '#F4BE65', '#082B3B', '#FFD78D', '#10B981', '#EF4444']

export function PatientTrendChart({ data }) {
  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
          <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#64748B' }} axisLine={false} />
          <YAxis tick={{ fontSize: 12, fill: '#64748B' }} axisLine={false} />
          <Tooltip cursor={{ strokeDasharray: '3 3' }} />
          <Line type="monotone" dataKey="patients" stroke="#003B3D" strokeWidth={2} dot={false} />
          <Line type="monotone" dataKey="appointments" stroke="#F4BE65" strokeWidth={2} dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}

export function RevenueChart({ data }) {
  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" />
          <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#64748B' }} axisLine={false} />
          <YAxis tick={{ fontSize: 12, fill: '#64748B' }} axisLine={false} />
          <Tooltip />
          <Bar dataKey="revenue" fill="#003B3D" radius={[4, 4, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

export function StatusChart({ data }) {
  const colors = data.map((_, i) => COLORS[i % COLORS.length])
  return (
    <div className="w-full h-64">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <Pie
            data={data}
            dataKey="value"
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            fill="#888"
            label
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={colors[index]} />
            ))}
          </Pie>
          <Tooltip />
          <Legend verticalAlign="top" align="right" height={100} />
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}
