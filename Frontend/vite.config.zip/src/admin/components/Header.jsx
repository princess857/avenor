import { useState } from 'react'
import { useLocation } from 'react-router-dom'
import { Menu, Search, Bell, User, Sun, Moon, Home } from 'lucide-react'
import { useTheme } from '../hooks/useTheme'

const breadcrumbMap = {
  '/admin/dashboard': 'Dashboard',
  '/admin/appointments': 'Appointments',
  '/admin/patients': 'Patients',
  '/admin/doctors': 'Doctors',
  '/admin/departments': 'Departments',
  '/admin/staff': 'Staff',
  '/admin/services': 'Medical Services',
  '/admin/billing': 'Billing',
  '/admin/analytics': 'Analytics',
  '/admin/notifications': 'Notifications',
  '/admin/website': 'Website Management',
  '/admin/settings': 'Settings',
}

export default function Header() {
  const [userMenuOpen, setUserMenuOpen] = useState(false)
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const { theme, toggleTheme } = useTheme()
  const location = useLocation()
  const current = breadcrumbMap[location.pathname] || 'Dashboard'

  return (
    <header className="bg-white dark:bg-[#0F2B30] border-b border-[#E2E8F0] dark:border-[#1E3A3D] sticky top-0 z-50">
      <div className="flex items-center justify-between px-4 md:px-6 h-16">
        <div className="flex items-center gap-3">
          <button
            className="lg:hidden p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#163A3F] rounded-lg"
            aria-label="Toggle sidebar"
          >
            <Menu size={20} />
          </button>
          <div className="hidden sm:flex items-center gap-2">
            <Home size={16} className="text-[#64748B] dark:text-gray-400" />
            <span className="text-xs font-medium text-[#64748B] dark:text-gray-400 uppercase tracking-wider">Avenor Admin</span>
            <span className="text-[#64748B] dark:text-gray-400">/</span>
            <span className="text-xs font-medium text-[#0F172A] dark:text-white">{current}</span>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-3">
          <div className="relative w-64">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search patients, doctors, appointments..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-gray-200 dark:border-[#1E3A3D] bg-gray-50 dark:bg-[#163A3F] text-gray-900 dark:text-white text-sm focus:outline-none focus:border-[#003B3D] focus:ring-1 focus:ring-[#003B3D] transition placeholder-gray-400 dark:placeholder-gray-500"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleTheme}
            className="p-2 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#163A3F] transition"
            aria-label="Toggle theme"
          >
            {theme === 'light' ? <Sun size={20} className="text-[#F4BE65]" /> : <Moon size={20} className="text-[#F4BE65]" />}
          </button>
          <button
            onClick={() => setNotificationsOpen(!notificationsOpen)}
            className="relative p-2 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#163A3F] transition"
            aria-label="Notifications"
          >
            <Bell size={20} />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-[#EF4444] border-2 border-white dark:border-[#0F2B30]" />
          </button>
          <button
            onClick={() => setUserMenuOpen(!userMenuOpen)}
            className="p-2 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-[#163A3F] transition"
            aria-label="User menu"
          >
            <User size={20} />
          </button>
        </div>
      </div>
    </header>
  )
}
