import { TrendingUp, TrendingDown } from 'lucide-react'

export function StatCard({ title, value, icon: Icon, trend, subtitle }) {
  const isPositive = trend >= 0
  return (
    <div className="bg-white dark:bg-[#0F2B30] rounded-2xl border border-[#E2E8F0] dark:border-[#1E3A3D] p-6 shadow-sm">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-[#64748B] dark:text-[#94A3B8] font-medium uppercase tracking-wider mb-1">{title}</p>
          <p className="text-2xl font-bold text-[#0F172A] dark:text-white">{value}</p>
          {subtitle && <p className="text-xs text-[#64748B] dark:text-[#64748B] mt-1">{subtitle}</p>}
        </div>
        <div className="w-10 h-10 rounded-xl bg-[#003B3D]/10 dark:bg-[#003B3D]/20 flex items-center justify-center text-[#003B3D] dark:text-[#F4BE65]">
          <Icon size={18} />
        </div>
      </div>
      {trend !== undefined && (
        <div className="mt-4 flex items-center gap-1">
          {isPositive ? <TrendingUp size={12} className="text-[#10B981]" /> : <TrendingDown size={12} className="text-[#EF4444]" />}
          <span className={`text-xs font-semibold ${isPositive ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
            {Math.abs(trend)}% vs last period
          </span>
        </div>
      )}
    </div>
  )
}

export default StatCard
