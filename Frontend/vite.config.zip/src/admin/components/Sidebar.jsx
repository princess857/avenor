import { NavLink, useLocation, useNavigate } from 'react-router-dom'
import {
  Layout, Calendar, Users, User, Building2, Mail, CreditCard, BarChart3, Bell, Settings, LogOut, ChevronLeft, ArrowRight, X,
} from 'lucide-react'
import { useAdminAuth } from '../hooks/useAdminAuth'

const adminNav = [
  { path: '/admin/dashboard', label: 'Dashboard', icon: Layout },
  { path: '/admin/appointments', label: 'Appointments', icon: Calendar },
  { path: '/admin/patients', label: 'Patients', icon: Users },
  { path: '/admin/doctors', label: 'Doctors', icon: User },
  { path: '/admin/departments', label: 'Departments', icon: Building2 },
  { path: '/admin/staff', label: 'Staff', icon: Mail },
  { path: '/admin/services', label: 'Medical Services', icon: Building2 },
  { path: '/admin/billing', label: 'Billing', icon: CreditCard },
  { path: '/admin/analytics', label: 'Analytics', icon: BarChart3 },
  { path: '/admin/notifications', label: 'Notifications', icon: Bell },
  { path: '/admin/website', label: 'Website Management', icon: Settings },
  { path: '/admin/settings', label: 'Settings', icon: Settings },
]

const LOGO_SVG = (
  <svg width="32" height="32" viewBox="0 0 48 48" fill="none">
    <rect x="2" y="2" width="44" height="44" rx="12" stroke="#F4BE65" strokeWidth="2" />
    <path d="M14 34 L24 12 L34 34" stroke="#F4BE65" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" fill="none" />
    <path d="M18 26 H30" stroke="#FFD78D" strokeWidth="2.5" strokeLinecap="round" />
    <circle cx="24" cy="12" r="2" fill="#FFD78D" />
  </svg>
)

function SidebarItem({ item, isActive }) {
  const Icon = item.icon
  return (
    <NavLink
      to={item.path}
      end={item.path === '/admin/dashboard'}
      className={({ isActive: active }) =>
        `flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition duration-200 ${
          active || isActive
            ? 'bg-[#002B30] text-[#F4BE65]'
            : 'text-[#CBD5E1] hover:bg-white/10 hover:text-white'
        }`
      }
    >
      <Icon size={18} />
      <span className="font-sans">{item.label}</span>
    </NavLink>
  )
}

export default function Sidebar({ collapsed = false, onToggle, isMobile = false, isOpen = false, onClose }) {
  const location = useLocation()
  const navigate = useNavigate()
  const { logout } = useAdminAuth()

  const handleSignOut = () => {
    logout()
    navigate('/admin/login', { replace: true })
  }

  if (isMobile) {
    return (
      <>
        <button
          onClick={onClose}
          className="lg:hidden p-2 text-gray-600 hover:bg-gray-100 rounded-lg mr-2"
          aria-label="Toggle navigation"
        >
          <ChevronLeft size={20} />
        </button>
        {isOpen && (
          <div className="fixed inset-0 z-[1100] bg-[#003B3D]/95 backdrop-blur-xl flex flex-col lg:hidden">
            <div className="p-4 flex items-center justify-between border-b border-white/10">
              <div className="flex items-center gap-3">
                {LOGO_SVG}
                <div className="leading-tight">
                  <div className="font-serif font-bold text-xl tracking-wide uppercase text-white">Avenor</div>
                  <div className="text-white/60 text-[10px] tracking-[0.25em] uppercase">Admin</div>
                </div>
              </div>
              <button onClick={onClose} className="p-2 text-white/70 hover:text-white">
                <X size={20} />
              </button>
            </div>
            <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
              {adminNav.map((item) => (
                <SidebarItem key={item.path} item={item} isActive={location.pathname === item.path} />
              ))}
            </nav>
            <div className="p-4 border-t border-white/10">
              <button
                onClick={handleSignOut}
                className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition text-sm"
              >
                <LogOut size={18} /> Sign out
              </button>
            </div>
          </div>
        )}
      </>
    )
  }

  return (
    <aside
      className={`fixed inset-y-0 left-0 z-50 bg-[#003B3D] text-white shrink-0 transition-all duration-300 ease-in-out ${
        collapsed ? 'w-20' : 'w-64'
      } border-r border-white/10`}
    >
      <div className="p-4 border-b border-white/10 flex items-center justify-between">
        <div className="flex items-center gap-2">
          {LOGO_SVG}
          {!collapsed && (
            <div className="leading-tight">
              <div className="font-serif font-bold text-xl tracking-wide uppercase">Avenor</div>
              <div className="text-white/60 text-[10px] tracking-[0.25em] uppercase">Admin</div>
            </div>
          )}
        </div>
        {collapsed && (
          <button onClick={onToggle} className="p-2 rounded-lg text-white/70 hover:bg-white/10 transition" aria-label="Expand sidebar">
            <ArrowRight size={16} />
          </button>
        )}
      </div>
      <nav className="flex-1 p-3 space-y-1">
        {adminNav.map((item) => (
          <SidebarItem
            key={item.path}
            item={item}
            isActive={location.pathname === item.path}
          />
        ))}
      </nav>
      <div className="p-3 border-t border-white/10">
        <button
          onClick={handleSignOut}
          className="w-full flex items-center gap-3 px-3 py-3 rounded-xl text-white/70 hover:text-white hover:bg-white/10 transition text-sm"
          aria-label="Sign out"
        >
          <LogOut size={18} />
          {!collapsed && <span>Sign out</span>}
        </button>
      </div>
    </aside>
  )
}
