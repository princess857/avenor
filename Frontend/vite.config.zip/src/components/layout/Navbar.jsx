import { Menu, X } from 'lucide-react'
import { useState } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import { site } from '../../config/site'
import AvenorLogo from './AvenorLogo'

const pathMap = {
  Home: '/',
  About: '/about',
  Departments: '/departments',
  Doctors: '/doctors',
  Services: '/services',
  Facilities: '/facilities',
  Contact: '/contact',
}

export default function Navbar() {
  const [open, setOpen] = useState(false)
  const navigate = useNavigate()
  return (
    <nav className="absolute top-[20px] left-1/2 -translate-x-1/2 z-[1000] w-full max-w-[calc(100%-24px)] sm:w-[92%] sm:max-w-6xl">
      <div style={{ background: 'rgba(15,65,65,0.75)', backdropFilter: 'blur(12px)', WebkitBackdropFilter: 'blur(12px)' }} className="rounded-[24px] px-4 sm:px-8 h-[70px] sm:h-[80px] flex items-center justify-between border border-white/10 shadow-lg">
        <AvenorLogo />
        <div className="hidden md:flex items-center gap-4 sm:gap-6">
          {site.nav.map((l) => (
            <NavLink key={l} to={pathMap[l]} className={({ isActive }) => `font-sans text-xs sm:text-sm transition relative ${isActive ? 'text-[#F4BE65]' : 'text-white/90 hover:text-[#F4BE65]'}`}>
              {({ isActive }) => (<>{l}{isActive && <span className="absolute -bottom-1 left-0 w-full h-0.5 bg-[#F4BE65]" />}</>)}
            </NavLink>
          ))}
          <button onClick={() => navigate('/book-appointment')} className="bg-[#F4BE65] text-[#002B30] font-sans font-semibold px-5 py-2 rounded-xl hover:bg-[#FFD78D] transition">Book Appointment</button>
        </div>
        <button className="relative z-50 md:hidden text-white" onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </div>
      {open && (
        <div className="md:hidden mt-3 bg-[#003B3D]/90 backdrop-blur-xl rounded-2xl p-4 flex flex-col gap-3 border border-white/10 shadow-2xl z-[1001]">
          {site.nav.map((l) => (
            <NavLink key={l} to={pathMap[l]} onClick={() => setOpen(false)} className="block text-white/90 text-sm py-2 rounded-lg hover:bg-white/10">{l}</NavLink>
          ))}
          <button onClick={() => { navigate('/book-appointment'); setOpen(false) }} className="bg-[#F4BE65] text-[#002B30] font-semibold px-5 py-2 rounded-xl">Book Appointment</button>
        </div>
      )}
    </nav>
  )
}
