import { ArrowLeft, ArrowRight } from 'lucide-react'

export default function HeroControls({ onPrev, onNext, slides, current, onDot }) {
  return (
    <>
      <button onClick={onPrev} className="absolute left-3 sm:left-6 top-1/2 -translate-y-1/2 z-20 text-white/80 hover:text-[#F4BE65]"><ArrowLeft className="w-7 h-7 sm:w-8 sm:h-8" /></button>
      <button onClick={onNext} className="absolute right-3 sm:right-6 top-1/2 -translate-y-1/2 z-20 text-white/80 hover:text-[#F4BE65]"><ArrowRight className="w-7 h-7 sm:w-8 sm:h-8" /></button>
      <div className="absolute bottom-6 sm:bottom-8 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {slides.map((_, idx) => (
          <button key={idx} onClick={() => onDot(idx)} className={`h-3 rounded-full transition-all ${idx === current ? 'bg-[#F4BE65] w-8' : 'bg-white/40 w-3'}`} />
        ))}
      </div>
    </>
  )
}
