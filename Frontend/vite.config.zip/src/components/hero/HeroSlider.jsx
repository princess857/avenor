import { motion, AnimatePresence } from 'framer-motion'
import { useState, useEffect, useRef } from 'react'
import { heroSlides } from '../../config/heroSlides'

export default function HeroSlider({ children }) {
  const [i, setI] = useState(0)
  const [paused, setPaused] = useState(false)
  const timer = useRef(null)

  useEffect(() => {
    // preload
    heroSlides.forEach((src) => { const img = new Image(); img.src = src })
  }, [])

  useEffect(() => {
    if (paused) return
    timer.current = setInterval(() => setI((p) => (p + 1) % heroSlides.length), 6000)
    return () => clearInterval(timer.current)
  }, [paused])

  const go = (d) => setI((p) => (p + d + heroSlides.length) % heroSlides.length)

  return (
    <section className="relative w-full overflow-hidden" style={{ minHeight: '100svh' }} onMouseEnter={() => setPaused(true)} onMouseLeave={() => setPaused(false)}>
      <AnimatePresence initial={false}>
        <motion.div key={i} initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '-100%' }} transition={{ duration: 0.9, ease: 'easeInOut' }} className="absolute inset-0">
          <img src={heroSlides[i]} alt="" className="w-full h-full object-cover" />
        </motion.div>
      </AnimatePresence>
      <div className="absolute inset-0 bg-gradient-to-r from-[#082B3B]/80 via-[#003B3D]/40 to-transparent z-10" />
      {children({ i, go, slides: heroSlides, setI })}
    </section>
  )
}
