import HeroSlider from './HeroSlider'
import HeroContent from './HeroContent'
import HeroStats from './HeroStats'
import HeroCurve from './HeroCurve'
import HeroControls from './HeroControls'

export default function HeroSection() {
  return (
    <HeroSlider>
      {({ i, go, slides, setI }) => (
        <>
          <div className="relative z-20 h-full flex flex-col justify-center gap-6 py-12 sm:py-16 md:py-24 px-2">
            <HeroContent />
            <div className="px-8 md:px-16 max-w-4xl">
              <HeroStats />
            </div>
          </div>
          <HeroControls onPrev={() => go(-1)} onNext={() => go(1)} slides={slides} current={i} onDot={setI} />
          <HeroCurve />
        </>
      )}
    </HeroSlider>
  )
}
